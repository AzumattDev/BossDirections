| `Version` | `Update Notes`                                                                   |
|-----------|----------------------------------------------------------------------------------|
| 1.0.1     | - Courtesty update for Valheim 0.217.22. Nothing changed besides a version bump. |
| 1.0.0     | - Initial Release                                                                |